export interface InvoiceLine {
  medicineName: string;
  quantity: number;
  unitPrice: number;
  discountPercent: number;
  lineTotal: number;
}

export interface InvoiceData {
  invoiceId: string;
  invoiceDate: string;
  customerName: string;
  paymentMethod: string;
  items: InvoiceLine[];
  subtotal: number;
  discountTotal: number;
  grandTotal: number;
}

function escapePdfText(input: string): string {
  return input.replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
}

function buildSimplePdf(lines: string[]): Uint8Array {
  const textLines = lines.map((line) => `(${escapePdfText(line)}) Tj T*`).join("\n");
  const content = `BT\n/F1 11 Tf\n50 800 Td\n14 TL\n${textLines}\nET`;
  const stream = `<< /Length ${content.length} >>\nstream\n${content}\nendstream`;

  const objects = [
    "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n",
    "2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n",
    "3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>\nendobj\n",
    `4 0 obj\n${stream}\nendobj\n`,
    "5 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n",
  ];

  let pdf = "%PDF-1.4\n";
  const offsets: number[] = [];

  for (const object of objects) {
    offsets.push(pdf.length);
    pdf += object;
  }

  const xrefStart = pdf.length;
  pdf += `xref\n0 ${objects.length + 1}\n`;
  pdf += "0000000000 65535 f \n";

  for (const offset of offsets) {
    pdf += `${offset.toString().padStart(10, "0")} 00000 n \n`;
  }

  pdf += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefStart}\n%%EOF`;

  return new TextEncoder().encode(pdf);
}

export function downloadInvoicePdf(invoice: InvoiceData): void {
  const lines: string[] = [
    "Pharmacy Invoice",
    "-------------------------",
    `Invoice: ${invoice.invoiceId}`,
    `Date: ${invoice.invoiceDate}`,
    `Customer: ${invoice.customerName || "Walk-in Customer"}`,
    `Payment: ${invoice.paymentMethod}`,
    "",
    "Items:",
  ];

  for (const item of invoice.items) {
    lines.push(
      `${item.medicineName} | Qty ${item.quantity} | Price Rs ${item.unitPrice.toFixed(2)} | Disc ${item.discountPercent.toFixed(2)}% | Total Rs ${item.lineTotal.toFixed(2)}`
    );
  }

  lines.push("");
  lines.push(`Subtotal: Rs ${invoice.subtotal.toFixed(2)}`);
  lines.push(`Discount: Rs ${invoice.discountTotal.toFixed(2)}`);
  lines.push(`Grand Total: Rs ${invoice.grandTotal.toFixed(2)}`);

  const pdfBytes = buildSimplePdf(lines);
  const blob = new Blob([pdfBytes], { type: "application/pdf" });
  const url = URL.createObjectURL(blob);

  const link = document.createElement("a");
  link.href = url;
  link.download = `${invoice.invoiceId}.pdf`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  URL.revokeObjectURL(url);
}
