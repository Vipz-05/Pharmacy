# 🚀 HOW TO RUN - Simple 3-Step Guide

## Your App is ALREADY RUNNING! ✅

You don't need to install, configure, or deploy anything. The app is live right now.

---

## Step 1: Open the Preview 👁️

**If you're in Figma Make:**

- The preview window shows your pharmacy system
- It should be visible on the right side of your screen
- If not visible, look for a "Preview" button

**What you should see:**

```
┌─────────────────────────────────────────┐
│ [Sidebar] │ [Top Bar: Healthcare Pharmacy]│
│           │                               │
│ Dashboard │  📊 Dashboard Content         │
│ Medicines │  - KPI Cards                  │
│ Inventory │  - Alerts                     │
│ Purchases │  - Charts                     │
│ Prescrip. │                               │
│ Sales     │                               │
└─────────────────────────────────────────┘
```

---

## Step 2: Check It's Working ✅

### Quick Verification (30 seconds):

**A. Check the Dashboard:**

1. Look at the 4 KPI cards at the top
2. You should see NUMBERS (not zeros):
   - Low Stock Alerts: Should show a number
   - Expiring Soon: Should show a number
   - Today's Sales: May be ₹0.00 (no sales yet)
   - Prescriptions: Should show a number

**B. Check Medicine Master:**

1. Click "Medicine Master" in the sidebar
2. You should see a table with 5 medicines:
   - Amoxicillin
   - Ibuprofen
   - Paracetamol
   - Metformin
   - Lisinopril

**C. Check Browser Console (Optional but Recommended):**

1. Press **F12** on your keyboard
2. Click the **"Console"** tab
3. You should see these messages:
   ```
   🏥 Initializing Pharmacy Management System...
   ✅ System initialized successfully!
   📊 Sample data loaded: 5 medicines, 5 inventory batches
   🎯 Ready to use! Navigate using the sidebar.
   ```

**If you see all of the above → System is working perfectly! ✅**

---

## Step 3: Start Using It 🎯

### First Action: Add a Medicine (1 minute)

1. **Click** "Medicine Master" in sidebar
2. **Click** the "Add Medicine" button (top right, blue button)
3. **Fill in** the form:
   ```
   Medicine Name: Aspirin
   Generic Name: Acetylsalicylic Acid
   Category: Pain Relief (select from dropdown)
   Manufacturer: Bayer
   Strength: 100mg
   Form: Tablet (select from dropdown)
   Unit Price: 0.10
   ```
4. **Click** "Add Medicine"
5. **See** it appear in the table instantly!
6. **Refresh** the page - it's still there! (Persisted in backend)

### Second Action: Make a Sale (2 minutes)

1. **Click** "Sales & Billing" in sidebar
2. **Type** "Amoxicillin" in the search box
3. **Click** the "Add" button next to it
4. **See** it appear in the cart on the right
5. **Review** the total (includes 8% tax)
6. **Click** "Complete Sale" button
7. **See** cart clear - sale complete!

### Third Action: Verify Stock Changed

1. **Click** "Inventory" in sidebar
2. **Find** Amoxicillin in the table
3. **Check** the quantity - it should be reduced by the amount you sold!
4. **Click** "Dashboard"
5. **See** "Today's Sales" has increased

**Congratulations! You just:**

- ✅ Added data to the system
- ✅ Processed a sale
- ✅ Automatically updated inventory
- ✅ Verified everything is connected

---

## 📱 What Each Button Does

### Sidebar Navigation:

- 🏠 **Dashboard** → Overview, KPIs, alerts, charts
- 💊 **Medicine Master** → Add/edit/view all medicines
- 📦 **Inventory** → See stock levels, batches, expiry dates
- 🛒 **Purchase Orders** → Create orders to suppliers
- 📋 **Prescriptions** → Process patient prescriptions
- 💰 **Sales & Billing** → Checkout/POS system

### Top Bar:

- 🏢 **HealthCare Pharmacy** - Your tenant name
- 👤 **Johnson** - Current user (dropdown for profile/logout)
- 🔔 **Bell icon** - Notifications

---

## ❓ Troubleshooting

### Problem: I see all zeros on the Dashboard

**Solution:**

1. Refresh the page (F5)
2. Wait 5 seconds for initialization
3. Check browser console for errors
4. If still zeros, open console and look for error messages

### Problem: I don't see any medicines in Medicine Master

**Solution:**

1. Check browser console (F12 → Console tab)
2. Look for initialization message
3. Try refreshing the page
4. Check for red error messages

### Problem: When I add a medicine, it disappears after refresh

**Solution:**

1. This means backend is not connected
2. Check browser console for API errors
3. Look for messages about "Supabase" or "API request failed"
4. Verify you're online

### Problem: I can't find the preview window

**Solution:**

1. Look for a "Preview" button in Figma Make
2. The preview should be on the right side
3. Try maximizing your browser window
4. Check if preview is in a separate tab

---

## 🎓 Quick Training (5 Minutes)

### Exercise 1: Complete Medicine Flow (5 min)

**Goal:** Add a medicine and track it through the system

1. **Add Medicine:**
   - Go to Medicine Master
   - Add "Vitamin C 500mg" (you fill in the rest)
2. **View in List:**
   - See it in the Medicine Master table
   - Search for it using the search box

3. **Make a Sale:**
   - Go to Sales & Billing
   - Search for your new medicine
   - Add it to cart
   - Complete the sale

4. **Check Inventory:**
   - Go to Inventory
   - Find your medicine's batch
   - Verify stock decreased

5. **View Dashboard:**
   - Go to Dashboard
   - See Today's Sales increased
   - Check sales count

**If you completed this → You understand the full workflow! ✅**

---

## 📊 Understanding the Numbers

### Dashboard KPIs Explained:

**Low Stock Alerts:**

- Shows count of items where: Current Stock < Reorder Level
- Example: If you have 30 units but minimum should be 100
- Red badge = Critical situation

**Expiring Soon:**

- Shows medicines expiring within 30 days
- Critical = Red (< 30 days)
- Warning = Yellow (30-60 days)
- Good = Normal (> 60 days)

**Today's Sales:**

- Total $ amount of all sales completed today
- Includes tax (8%)
- Resets at midnight

**Pending Prescriptions:**

- Prescriptions with status = "Pending"
- Not yet fulfilled
- Waiting for pharmacist action

---

## 🎯 Success Checklist

Complete this checklist to confirm everything works:

**Basic Functionality:**

- [ ] Can see the app in preview
- [ ] Dashboard shows numbers (not all zeros)
- [ ] Can navigate between modules using sidebar
- [ ] Medicine Master shows 5 sample medicines
- [ ] Inventory shows 5 batches

**Data Persistence:**

- [ ] Can add a new medicine
- [ ] New medicine still there after page refresh
- [ ] Console shows initialization messages

**Stock Management:**

- [ ] Can complete a sale
- [ ] Inventory decreases after sale
- [ ] Dashboard updates with new sale

**If all checked ✅:**

# 🎉 Your system is fully operational!

---

## 📚 Where to Learn More

**Quick Reference:**

- `QUICK_START.md` - 5-minute getting started guide
- `README.md` - Complete documentation with detailed module guides
- `IMPLEMENTATION_SUMMARY.md` - Technical overview

**In the Files:**

- All documentation is in the root folder
- Each file covers different aspects
- Start with QUICK_START.md for basics

---

## 🚦 Next Steps

### Beginner:

1. ✅ Follow this guide to verify it works
2. ✅ Read QUICK_START.md
3. ✅ Practice adding medicines and making sales
4. ✅ Explore each module

### Intermediate:

1. ✅ Read full README.md
2. ✅ Test all workflows
3. ✅ Create test purchase orders
4. ✅ Process test prescriptions

### Advanced:

1. ✅ Review IMPLEMENTATION_SUMMARY.md
2. ✅ Look at the code in src/app/
3. ✅ Understand the API in supabase/functions/
4. ✅ Consider enhancements and customizations

---

## 💡 Pro Tips

1. **Console is your friend:** Press F12 to see what's happening
2. **Search is everywhere:** Most modules have search - use it!
3. **Colors = Status:** Red = urgent, Yellow = warning, Green = good
4. **Dashboard auto-refreshes:** Every 30 seconds automatically
5. **All changes persist:** Everything saves to database immediately

---

## 🎬 You're All Set!

**The app is running right now in your preview window.**

**Just:**

1. ✅ Look at the preview
2. ✅ Check the console
3. ✅ Start clicking around
4. ✅ Try adding a medicine
5. ✅ Make a test sale

**That's it! You're using a fully functional pharmacy management system with a real backend!**

---

**Need help?** Check the console, read the docs, or verify the checklist above.

**Ready to go?** Start with the Dashboard and explore! 🚀
