const express = require('express');
const router = express.Router();
const pool = require('../db');
const { sendServerError } = require('../utils/errorResponse');

// Get all purchase orders
router.get('/', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        po.purchase_order_id as id,
        'PO' || po.purchase_order_id::text as poNumber,
        po.order_date as orderDate,
        s.supplier_id as supplierId,
        s.supplier_name as supplierName,
        po.status,
        COUNT(poi.item_id) as itemCount,
        COALESCE(SUM(poi.quantity * poi.unit_price), 0) as totalAmount
      FROM PURCHASE_ORDER po
      JOIN SUPPLIER s ON po.supplier_id = s.supplier_id
      LEFT JOIN PURCHASE_ORDER_ITEM poi ON po.purchase_order_id = poi.purchase_order_id
      GROUP BY po.purchase_order_id, s.supplier_id, s.supplier_name
      ORDER BY po.order_date DESC
    `);
    
    res.json({ success: true, data: result.rows });
  } catch (err) {
    return sendServerError(res, err, 'Error fetching purchase orders:');
  }
});

// Create purchase order
router.post('/', async (req, res) => {
  const client = await pool.connect();
  
  try {
    const { supplierId, items } = req.body;

    if (!supplierId || !items || items.length === 0) {
      return res.status(400).json({ success: false, error: 'Supplier ID and items required' });
    }

    await client.query('BEGIN');

    // Create PO
    const poResult = await client.query(
      `INSERT INTO PURCHASE_ORDER (supplier_id, order_date, status)
       VALUES ($1, CURRENT_DATE, 'pending')
       RETURNING *`,
      [supplierId]
    );

    const poId = poResult.rows[0].purchase_order_id;

    // Add items
    for (const item of items) {
      await client.query(
        `INSERT INTO PURCHASE_ORDER_ITEM (purchase_order_id, medicine_id, quantity, unit_price)
         VALUES ($1, $2, $3, $4)`,
        [poId, item.medicineId, item.quantity, item.unitPrice]
      );
    }

    await client.query('COMMIT');

    res.status(201).json({ success: true, data: { purchase_order_id: poId } });
  } catch (err) {
    await client.query('ROLLBACK');
    return sendServerError(res, err, 'Error creating purchase order:');
  } finally {
    client.release();
  }
});

// Update PO status
router.patch('/:id/status', async (req, res) => {
  const client = await pool.connect();

  try {
    const { id } = req.params;
    const { status } = req.body;
    const normalizedStatus = typeof status === 'string' ? status.toLowerCase() : '';
    const allowedStatuses = ['pending', 'approved', 'received', 'cancelled'];

    if (!allowedStatuses.includes(normalizedStatus)) {
      return res.status(400).json({ success: false, error: 'Invalid purchase order status' });
    }

    await client.query('BEGIN');

    const existingResult = await client.query(
      'SELECT * FROM PURCHASE_ORDER WHERE purchase_order_id = $1 FOR UPDATE',
      [id]
    );

    if (existingResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ success: false, error: 'Purchase order not found' });
    }

    const currentStatus = (existingResult.rows[0].status || '').toLowerCase();

    const result = await client.query(
      'UPDATE PURCHASE_ORDER SET status = $1 WHERE purchase_order_id = $2 RETURNING *',
      [normalizedStatus, id]
    );

    // Add inventory one time when transitioning into "received".
    if (normalizedStatus === 'received' && currentStatus !== 'received') {
      const poItemsResult = await client.query(
        `SELECT medicine_id, quantity, unit_price
         FROM PURCHASE_ORDER_ITEM
         WHERE purchase_order_id = $1`,
        [id]
      );

      for (const item of poItemsResult.rows) {
        const generatedBatchNumber = `PO-${id}-M-${item.medicine_id}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
        const purchasePrice = Number(item.unit_price) || 0;
        const sellingPrice = purchasePrice;

        await client.query(
          `INSERT INTO MEDICINE_BATCH
            (medicine_id, batch_number, expiry_date, purchase_price, selling_price, quantity_available)
           VALUES ($1, $2, NULL, $3, $4, $5)`,
          [item.medicine_id, generatedBatchNumber, purchasePrice, sellingPrice, item.quantity]
        );
      }
    }

    await client.query('COMMIT');
    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    await client.query('ROLLBACK');
    return sendServerError(res, err, 'Error updating PO:');
  } finally {
    client.release();
  }
});

module.exports = router;
