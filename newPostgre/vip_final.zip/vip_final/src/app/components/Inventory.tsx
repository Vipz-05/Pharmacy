﻿import { useState, useEffect } from "react";
import { formatDate } from "../utils/date";
import { Search, AlertTriangle, Package, Trash2 } from "lucide-react";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { Label } from "./ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { cn } from "./ui/utils";
import { inventoryApi, medicinesApi } from "../utils/api";

interface InventoryItem {
  id: string;
  medicineId: string;
  medicineName: string;
  manufacturer?: string;
  batchNumber: string;
  quantity: number;
  reorderLevel: number;
  expiryDate: string;
  unitPrice: number;
  location: string;
}

function normalizeInventoryItem(item: any): InventoryItem {
  const get = (camel: string, lower: string) =>
    item?.[camel] !== undefined ? item[camel] : item?.[lower];

  return {
    id: String(get("id", "id") ?? ""),
    medicineId: String(get("medicineId", "medicineid") ?? ""),
    medicineName: String(get("medicineName", "medicinename") ?? ""),
    manufacturer: get("manufacturer", "manufacturer")
      ? String(get("manufacturer", "manufacturer"))
      : "",
    batchNumber: String(get("batchNumber", "batchnumber") ?? ""),
    quantity: Number(get("quantity", "quantity") ?? 0),
    reorderLevel: Number(get("reorderLevel", "reorderlevel") ?? 100),
    expiryDate: get("expiryDate", "expirydate")
      ? String(get("expiryDate", "expirydate"))
      : "",
    unitPrice: Number(get("unitPrice", "unitprice") ?? 0),
    location: get("location", "location") ? String(get("location", "location")) : "",
  };
}

export function Inventory() {
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [loading, setLoading] = useState(true);
  const [deletingBatchId, setDeletingBatchId] = useState<string | null>(null);

  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [medicines, setMedicines] = useState<any[]>([]);
  const [newBatch, setNewBatch] = useState<Partial<InventoryItem>>({
    medicineId: "",
    medicineName: "",
    manufacturer: "",
    expiryDate: "",
    quantity: 0,
    location: "Shelf A",
    reorderLevel: 100, // sensible default
  });

  useEffect(() => {
    loadInventory();
    loadMedicines();
  }, []);

  const loadMedicines = async () => {
    try {
      const res = await medicinesApi.getAll();
      setMedicines((res.data || []).map((m) => ({ ...m, id: String(m.id) })));
    } catch (e) {
      console.error("Error loading medicines", e);
    }
  };

  const loadInventory = async () => {
    try {
      setLoading(true);
      const response = await inventoryApi.getAll();
      setInventory((response.data || []).map(normalizeInventoryItem));
    } catch (error) {
      console.error("Error loading inventory:", error);
    } finally {
      setLoading(false);
    }
  };

  const filteredInventory = inventory.filter((item) => {
    const matchesSearch =
      (item.medicineName || "").toLowerCase().includes(searchTerm.toLowerCase()) ||
      (item.batchNumber || "").toLowerCase().includes(searchTerm.toLowerCase());

    if (filterStatus === "all") return matchesSearch;
    
    const expiryStatus = getExpiryStatus(item.expiryDate).status;
    if (filterStatus === "expiring") {
      return matchesSearch && (expiryStatus === "critical" || expiryStatus === "warning");
    }
    if (filterStatus === "low-stock") {
      return matchesSearch && item.quantity < (item.reorderLevel || 100);
    }
    
    return matchesSearch;
  });

  const totalValue = filteredInventory.reduce(
    (sum, item) => sum + item.quantity * item.unitPrice,
    0
  );

  const handleDeleteBatch = async (item: InventoryItem) => {
    if (
      !window.confirm(
        `Delete batch ${item.batchNumber} for ${item.medicineName}? This action cannot be undone.`
      )
    ) {
      return;
    }

    try {
      setDeletingBatchId(item.id);
      await inventoryApi.deleteBatch(item.id);
      await loadInventory();
    } catch (error) {
      console.error("Error deleting inventory batch:", error);
      alert(error instanceof Error ? error.message : "Failed to delete batch.");
    } finally {
      setDeletingBatchId(null);
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1>Inventory Management</h1>
        <p className="text-gray-500 mt-1">Batch-wise stock view with expiry tracking</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Total Batches</p>
              <p className="text-2xl mt-1">{filteredInventory.length}</p>
            </div>
            <Package className="w-8 h-8 text-blue-500" />
          </div>
        </div>
        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Inventory Value</p>
              <p className="text-2xl mt-1">Rs {totalValue.toFixed(2)}</p>
            </div>
            <Package className="w-8 h-8 text-green-500" />
          </div>
        </div>
        <div className="bg-white p-4 rounded-lg border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-500">Expiring Soon</p>
              <p className="text-2xl mt-1">
                {inventory.filter(
                  (item) =>
                    getExpiryStatus(item.expiryDate).status === "critical" ||
                    getExpiryStatus(item.expiryDate).status === "warning"
                ).length}
              </p>
            </div>
            <AlertTriangle className="w-8 h-8 text-orange-500" />
          </div>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input
            placeholder="Search by medicine or batch..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Items</SelectItem>
            <SelectItem value="expiring">Expiring Soon</SelectItem>
            <SelectItem value="low-stock">Low Stock</SelectItem>
          </SelectContent>
        </Select>
        <Button onClick={() => setIsAddDialogOpen(true)} className="ml-auto">
          Add Stock
        </Button>
      </div>

      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Stock Batch</DialogTitle>
            <DialogDescription>Enter batch details below.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Medicine</Label>
                <Select
                  value={newBatch.medicineId}
                  onValueChange={(val) => {
                    const med = medicines.find((m) => m.id === val);
                    setNewBatch((prev) => ({
                      ...prev,
                      medicineId: val,
                      medicineName: med?.name || "",
                    }));
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select medicine" />
                  </SelectTrigger>
                  <SelectContent>
                    {medicines.map((m) => (
                      <SelectItem key={m.id} value={m.id}>
                        {m.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Batch Number</Label>
                <Input
                  value="Auto-generated on save"
                  disabled
                />
              </div>
              <div className="space-y-2">
                <Label>Expiry Date</Label>
                <Input
                  type="date"
                  value={newBatch.expiryDate}
                  onChange={(e) =>
                    setNewBatch((p) => ({ ...p, expiryDate: e.target.value }))
                  }
                />
              </div>
              <div className="space-y-2">
                <Label>Quantity</Label>
                <Input
                  type="number"
                  value={newBatch.quantity || ""}
                  onChange={(e) =>
                    setNewBatch((p) => ({
                      ...p,
                      quantity: parseInt(e.target.value) || 0,
                    }))
                  }
                />
              </div>
              <div className="space-y-2">
                <Label>Location</Label>
                <Input
                  value={newBatch.location}
                  onChange={(e) =>
                    setNewBatch((p) => ({ ...p, location: e.target.value }))
                  }
                />
              </div>
              <div className="space-y-2">
                <Label>Reorder Level</Label>
                <Input
                  type="number"
                  value={newBatch.reorderLevel || ""}
                  onChange={(e) =>
                    setNewBatch((p) => ({
                      ...p,
                      reorderLevel: parseInt(e.target.value) || 0,
                    }))
                  }
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={async () => {
              // basic required fields check
              if (!newBatch.medicineId || !Number.isFinite(Number(newBatch.quantity)) || Number(newBatch.quantity) <= 0) {
                alert("Please choose a medicine and valid quantity.");
                return;
              }
              try {
                await inventoryApi.addBatch({
                  medicineId: newBatch.medicineId,
                  expiryDate: newBatch.expiryDate || null,
                  quantity: Number(newBatch.quantity),
                  location: (newBatch.location || "").trim() || "Shelf A",
                  reorderLevel: Number(newBatch.reorderLevel || 100),
                });
                setIsAddDialogOpen(false);
                setNewBatch({
                  medicineId: "",
                  medicineName: "",
                  expiryDate: "",
                  quantity: 0,
                  location: "Shelf A",
                  reorderLevel: 100,
                });
                loadInventory();
              } catch (err) {
                console.error("Error adding batch", err);
              }
            }}>
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <div className="bg-white rounded-lg border border-gray-200">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Medicine</TableHead>
              <TableHead>Batch Number</TableHead>
              <TableHead>Quantity</TableHead>
              <TableHead>Expiry Date</TableHead>
              <TableHead>Expiry Status</TableHead>
              <TableHead>Location</TableHead>
              <TableHead>Unit Price</TableHead>
              <TableHead>Batch Value</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredInventory.map((item, index) => {
              const expiryStatus = getExpiryStatus(item.expiryDate);
              const stockStatus = getStockStatus(item.quantity);
              const batchValue = item.quantity * item.unitPrice;

              return (
                <TableRow
                  key={item.id || index}
                  className={cn(
                    expiryStatus.status === "critical" && "bg-red-50",
                    expiryStatus.status === "warning" && "bg-yellow-50"
                  )}
                >
                  <TableCell>
                    <div>
                      <p>{item.medicineName}</p>
                      <p className="text-xs text-gray-500">{item.manufacturer}</p>
                    </div>
                  </TableCell>
                  <TableCell>{item.batchNumber}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <span>{item.quantity}</span>
                      {stockStatus.status !== "adequate" && (
                        <Badge variant={stockStatus.variant as any} className="text-xs">
                          {stockStatus.status}
                        </Badge>
                      )}
                    </div>
                  </TableCell>
                  <TableCell>{item.expiryDate ? formatDate(item.expiryDate) : "-"}</TableCell>
                  <TableCell>
                    <Badge variant={expiryStatus.variant as any}>
                      {expiryStatus.label}
                    </Badge>
                  </TableCell>
                  <TableCell>{item.location}</TableCell>
                  <TableCell>Rs {Number(item.unitPrice || 0).toFixed(2)}</TableCell>
                  <TableCell>Rs {Number(batchValue || 0).toFixed(2)}</TableCell>
                  <TableCell>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDeleteBatch(item)}
                      disabled={deletingBatchId === item.id}
                    >
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

function getExpiryStatus(expiryDate: string) {
  const today = new Date();
  const expiry = new Date(expiryDate);
  const daysUntilExpiry = Math.floor((expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

  if (daysUntilExpiry < 0) return { status: "expired", label: "Expired", variant: "destructive" };
  if (daysUntilExpiry < 30) return { status: "critical", label: "Critical", variant: "destructive" };
  if (daysUntilExpiry < 60) return { status: "warning", label: "Warning", variant: "secondary" };
  return { status: "good", label: "Good", variant: "default" };
}

function getStockStatus(quantity: number) {
  if (quantity < 50) return { status: "critical", variant: "destructive" };
  if (quantity < 100) return { status: "low", variant: "secondary" };
  return { status: "adequate", variant: "default" };
}

