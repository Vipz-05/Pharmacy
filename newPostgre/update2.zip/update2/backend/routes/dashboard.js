const express = require('express');
const router = express.Router();
const pool = require('../db');
const { sendServerError } = require('../utils/errorResponse');

// Get dashboard stats
router.get('/stats', async (req, res) => {
  try {
    // Get medicines count
    const medicines = await pool.query('SELECT COUNT(*) as count FROM MEDICINE');

    // Get low stock items (quantity < 100 reorder level)
    const lowStock = await pool.query(`
      SELECT COUNT(*) as count FROM MEDICINE_BATCH
      WHERE quantity_available < COALESCE(reorder_level, 100)
    `);

    // Get expiring medicines (within 30 days)
    const expiringResult = await pool.query(`
      SELECT COUNT(*) as count FROM MEDICINE_BATCH
      WHERE expiry_date <= CURRENT_DATE + INTERVAL '30 days'
      AND expiry_date > CURRENT_DATE
    `);

    // Get already expired items
    const expiredResult = await pool.query(`
      SELECT COUNT(*) as count FROM MEDICINE_BATCH
      WHERE expiry_date <= CURRENT_DATE
    `);

    // Get today's sales
    const todayResult = await pool.query(`
      SELECT 
        COUNT(*) as count,
        COALESCE(SUM(total_amount), 0) as total
      FROM PHARMACY_SALE
      WHERE DATE(sale_date) = CURRENT_DATE
    `);

    // Get pending prescriptions
    const prescriptions = await pool.query(
      "SELECT COUNT(*) as count FROM PRESCRIPTION WHERE status = 'pending'"
    );

    // Get total inventory value
    const inventoryValue = await pool.query(`
      SELECT COALESCE(SUM(quantity_available * selling_price), 0) as value
      FROM MEDICINE_BATCH
    `);

    res.json({
      success: true,
      data: {
        totalMedicines: parseInt(medicines.rows[0].count),
        lowStockItems: parseInt(lowStock.rows[0].count),
        expiringMedicines: parseInt(expiringResult.rows[0].count),
        expiredItems: parseInt(expiredResult.rows[0].count),
        dailySales: parseFloat(todayResult.rows[0].total),
        todaySalesCount: parseInt(todayResult.rows[0].count),
        pendingPrescriptions: parseInt(prescriptions.rows[0].count),
        totalInventoryValue: parseFloat(inventoryValue.rows[0].value),
      }
    });
  } catch (err) {
    return sendServerError(res, err, 'Error fetching dashboard stats:');
  }
});

module.exports = router;
