const express = require('express');
const router = express.Router();
const pool = require('../db');
const { sendServerError } = require('../utils/errorResponse');

// Get all inventory batches with medicine details
router.get('/', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        mb.batch_id as "id",
        mb.medicine_id as "medicineId",
        m.name as "medicineName",
        m.manufacturer as "manufacturer",
        mb.batch_number as "batchNumber",
        mb.quantity_available as "quantity",
        COALESCE(mb.reorder_level, 100) as "reorderLevel",
        mb.expiry_date as "expiryDate",
        m.unit_price as "unitPrice",
        COALESCE(mb.location, 'Shelf A') as "location"
      FROM MEDICINE_BATCH mb
      JOIN MEDICINE m ON mb.medicine_id = m.medicine_id
      ORDER BY m.name ASC
    `);
    
    res.json({ success: true, data: result.rows });
  } catch (err) {
    return sendServerError(res, err, 'Error fetching inventory:');
  }
});

// Add medicine batch (addMedicineBatch API)
router.post('/', async (req, res) => {
  try {
    const { medicineId, expiryDate, quantity, location, reorderLevel } = req.body;

    if (!medicineId || !Number.isFinite(Number(quantity)) || Number(quantity) <= 0) {
      return res.status(400).json({ success: false, error: 'Medicine ID and valid quantity are required' });
    }

    // Check if medicine exists
    const medicineCheck = await pool.query('SELECT unit_price FROM MEDICINE WHERE medicine_id = $1', [medicineId]);
    if (medicineCheck.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Medicine not found' });
    }

    const unitPrice = Number(medicineCheck.rows[0].unit_price || 0);

    const normalizedLocation =
      typeof location === 'string' && location.trim().length > 0 ? location.trim() : 'Shelf A';
    const parsedReorderLevel = Number(reorderLevel);
    const normalizedReorderLevel =
      Number.isFinite(parsedReorderLevel) && parsedReorderLevel >= 0 ? parsedReorderLevel : 100;

    const result = await pool.query(
      `WITH next_batch AS (
         SELECT nextval(pg_get_serial_sequence('medicine_batch', 'batch_id')) AS batch_id
       )
       INSERT INTO MEDICINE_BATCH
        (batch_id, medicine_id, batch_number, expiry_date, purchase_price, selling_price, location, reorder_level, quantity_available)
       SELECT
        next_batch.batch_id,
        $1,
        'BT-' || next_batch.batch_id::text,
        $2,
        $3,
        $3,
        $4,
        $5,
        $6
       FROM next_batch
       RETURNING *`,
      [
        medicineId,
        expiryDate || null,
        unitPrice,
        normalizedLocation,
        normalizedReorderLevel,
        Number(quantity),
      ]
    );

    res.status(201).json({ success: true, data: result.rows[0] });
  } catch (err) {
    return sendServerError(res, err, 'Error adding batch:');
  }
});

// Update batch stock
router.patch('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { quantity, operation } = req.body;

    // Get current quantity
    const current = await pool.query('SELECT quantity_available FROM MEDICINE_BATCH WHERE batch_id = $1', [id]);
    if (current.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Batch not found' });
    }

    let newQuantity = current.rows[0].quantity_available;
    if (operation === 'add') {
      newQuantity += quantity;
    } else if (operation === 'subtract') {
      newQuantity = Math.max(0, newQuantity - quantity);
    } else if (operation === 'set') {
      newQuantity = quantity;
    }

    const result = await pool.query(
      'UPDATE MEDICINE_BATCH SET quantity_available = $1 WHERE batch_id = $2 RETURNING *',
      [newQuantity, id]
    );

    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    return sendServerError(res, err, 'Error updating batch:');
  }
});

module.exports = router;
