const express = require('express');
const router = express.Router();
const pool = require('../db');
const { sendServerError } = require('../utils/errorResponse');

function mapMedicineRow(row) {
  return {
    id: row.medicine_id,
    medicineCode: row.medicine_code,
    name: row.name,
    category: row.category,
    manufacturer: row.manufacturer,
    dosageForm: row.dosage_form,
    strength: row.strength,
    prescriptionRequired: row.prescription_required,
    createdAt: row.created_at,
    genericName: row.generic_name || row.name,
    form: row.dosage_form,
    price: Number(row.unit_price || 0),
    status: 'active',
  };
}

// List all medicines
router.get('/', async (req, res) => {
  try {
    const { search } = req.query;
    let query = 'SELECT * FROM MEDICINE ORDER BY name ASC';
    const params = [];

    if (search) {
      query = `SELECT * FROM MEDICINE 
               WHERE name ILIKE $1 OR generic_name ILIKE $1 OR medicine_code ILIKE $1 OR manufacturer ILIKE $1
               ORDER BY name ASC`;
      params.push(`%${search}%`);
    }

    const result = await pool.query(query, params);
    
    // Map database columns to camelCase for frontend
    const mappedData = result.rows.map(mapMedicineRow);
    
    res.json({ success: true, data: mappedData });
  } catch (err) {
    return sendServerError(res, err, 'Error fetching medicines:');
  }
});

// Get single medicine
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('SELECT * FROM MEDICINE WHERE medicine_id = $1', [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Medicine not found' });
    }

    const mappedData = mapMedicineRow(result.rows[0]);

    res.json({ success: true, data: mappedData });
  } catch (err) {
    return sendServerError(res, err, 'Error fetching medicine:');
  }
});

// Create medicine
router.post('/', async (req, res) => {
  try {
    const { name, genericName, category, manufacturer, dosageForm, strength, prescriptionRequired, medicineCode, price } = req.body;

    if (!name || !medicineCode) {
      return res.status(400).json({ success: false, error: 'Name and medicine code are required' });
    }

    const parsedPrice = Number(price);
    const unitPrice = Number.isFinite(parsedPrice) ? parsedPrice : 0;
    const normalizedGenericName =
      typeof genericName === 'string' && genericName.trim().length > 0 ? genericName.trim() : name;

    const result = await pool.query(
      `INSERT INTO MEDICINE (medicine_code, name, generic_name, category, manufacturer, dosage_form, strength, unit_price, prescription_required)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING *`,
      [
        medicineCode,
        name,
        normalizedGenericName,
        category,
        manufacturer,
        dosageForm,
        strength,
        unitPrice,
        prescriptionRequired !== false,
      ]
    );

    res.status(201).json({ success: true, data: mapMedicineRow(result.rows[0]) });
  } catch (err) {
    return sendServerError(res, err, 'Error creating medicine:');
  }
});

// Update medicine
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { name, genericName, category, manufacturer, dosageForm, strength, prescriptionRequired, price } = req.body;

    let parsedPrice = null;
    if (price !== undefined) {
      parsedPrice = Number(price);
      if (!Number.isFinite(parsedPrice)) {
        return res.status(400).json({ success: false, error: 'Invalid price' });
      }
    }

    const result = await pool.query(
      `UPDATE MEDICINE 
       SET name = COALESCE($1, name),
           generic_name = COALESCE($2, generic_name),
           category = COALESCE($3, category),
           manufacturer = COALESCE($4, manufacturer),
           dosage_form = COALESCE($5, dosage_form),
           strength = COALESCE($6, strength),
           unit_price = COALESCE($7, unit_price),
           prescription_required = COALESCE($8, prescription_required)
       WHERE medicine_id = $9
       RETURNING *`,
      [name, genericName, category, manufacturer, dosageForm, strength, parsedPrice, prescriptionRequired, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Medicine not found' });
    }

    res.json({ success: true, data: mapMedicineRow(result.rows[0]) });
  } catch (err) {
    return sendServerError(res, err, 'Error updating medicine:');
  }
});

// Delete medicine
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('DELETE FROM MEDICINE WHERE medicine_id = $1 RETURNING *', [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Medicine not found' });
    }

    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    return sendServerError(res, err, 'Error deleting medicine:');
  }
});

module.exports = router;
