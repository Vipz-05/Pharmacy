# 🚀 Quick Start Guide - 5 Minutes to Get Running

## ⚡ Immediate Start (3 Steps)

### Step 1: The App is Already Running! ✅
- You're viewing it right now in Figma Make
- The preview window shows your pharmacy system
- Backend is connected and ready

### Step 2: Automatic Setup ✅
The system automatically:
- Loads 5 sample medicines
- Creates 5 inventory batches
- Initializes the database
- **This happens in the background when you first load the page**

### Step 3: Start Exploring! 🎯
Click through the sidebar to see each module.

---

## 🎮 Try These Actions (5 Minutes)

### Action 1: View the Dashboard (30 seconds)
1. Look at the 4 KPI cards at the top
2. Scroll down to see Low Stock Alerts
3. Check the Expiring Medicines list
4. View the charts at the bottom

**What to notice:**
- Numbers are REAL from the database
- Low stock items show up because some have quantity < reorder level
- Expiring items appear based on actual expiry dates

---

### Action 2: Add a New Medicine (1 minute)
1. Click **"Medicine Master"** in sidebar
2. Click **"Add Medicine"** button (top right)
3. Fill in:
   ```
   Medicine Name: Aspirin
   Generic Name: Acetylsalicylic Acid
   Category: Pain Relief
   Manufacturer: Bayer
   Strength: 100mg
   Form: Tablet
   Price: 0.10
   ```
4. Click **"Add Medicine"**
5. See it appear in the table instantly!

---

### Action 3: Make a Sale (2 minutes)
1. Click **"Sales & Billing"** in sidebar
2. In the search box, type "**Amoxicillin**"
3. Click **"Add"** button next to it
4. See it appear in the cart on the right
5. Change quantity using +/- buttons if you want
6. Review the Total (includes 8% tax)
7. Click **"Complete Sale"**
8. Cart clears - sale complete!

**What just happened:**
- ✅ Sale recorded in database
- ✅ Stock automatically deducted from inventory
- ✅ Dashboard will update on next refresh

---

### Action 4: Verify Stock Changed (1 minute)
1. Click **"Inventory"** in sidebar
2. Find the Amoxicillin batch in the table
3. Check the quantity - it should be reduced!
4. Go back to **Dashboard**
5. Wait 30 seconds (or refresh page)
6. See "Today's Sales" increased

---

## 📊 What Each Module Does

| Module | Purpose | Key Action |
|--------|---------|------------|
| 🏠 **Dashboard** | Overview & Alerts | Monitor KPIs |
| 💊 **Medicine Master** | Catalog Management | Add/Edit medicines |
| 📦 **Inventory** | Stock Tracking | View batch details |
| 🛒 **Purchase Orders** | Ordering from Suppliers | Create POs |
| 📋 **Prescriptions** | Patient Prescriptions | Fulfill Rx |
| 💰 **Sales & Billing** | POS System | Make sales |

---

## 🎯 Sample Data Included

### Medicines (5):
1. Amoxicillin 500mg - Antibiotic
2. Ibuprofen 400mg - Pain Relief
3. Paracetamol 500mg - Pain Relief
4. Metformin 850mg - Diabetes
5. Lisinopril 10mg - Cardiovascular

### Inventory Batches (5):
- Various quantities (50 to 800 units)
- Different expiry dates (2026)
- Some are low stock (triggers alerts)
- Some expiring soon (triggers warnings)

---

## 🔄 How Stock Updates Automatically

```
When you complete a SALE:
├─ Stock deducted from inventory
├─ Dashboard "Today's Sales" increases
└─ Low stock alerts update if threshold reached

When you fulfill a PRESCRIPTION:
├─ Stock deducted from inventory
└─ Prescription status changes to "Fulfilled"

When a PURCHASE ORDER is received:
├─ Stock added to inventory
└─ Order status changes to "Received"
```

---

## 🎨 Understanding the UI

### Color Codes:

**Status Badges:**
- 🟢 **Green** = Active, Good, Fulfilled, Approved
- 🟡 **Yellow/Orange** = Warning, Pending, Low
- 🔴 **Red** = Critical, Expired, Cancelled
- ⚪ **Gray** = Inactive, Secondary

**Inventory Row Colors:**
- 🔴 **Red background** = Expires in < 30 days (CRITICAL)
- 🟡 **Yellow background** = Expires in 30-60 days (WARNING)
- ⚪ **White background** = Expires in > 60 days (GOOD)

---

## ✅ Checklist: Is Everything Working?

Go through this checklist:

- [ ] Dashboard shows 4 KPI numbers (not zeros)
- [ ] Medicine Master shows 5 medicines in table
- [ ] Inventory shows 5 batches in table
- [ ] Can add a new medicine
- [ ] Can complete a sale
- [ ] Stock decreases after sale
- [ ] Dashboard updates (wait 30s or refresh)

**If all checked ✅ = System is fully functional!**

---

## 🐛 Quick Fixes

**Issue: All numbers show 0**
- Refresh the page
- Check browser console (F12)
- Wait a few seconds for initialization

**Issue: Can't add medicine**
- Check that all required fields are filled
- Look for error message in browser console

**Issue: Stock not updating**
- Refresh the Inventory page
- Wait a moment for backend to process
- Check console for errors

---

## 🎉 You're Ready!

**That's it! You now have a fully functional pharmacy management system.**

### What to do next:
1. ✅ Explore each module
2. ✅ Try adding more medicines
3. ✅ Make test sales
4. ✅ Create purchase orders
5. ✅ Process prescriptions
6. ✅ Watch the dashboard update

### Need detailed info?
- See **README.md** for comprehensive documentation
- Every module is explained step-by-step
- Troubleshooting section included

---

## 💡 Pro Tips

1. **Search is fast**: Type in any search box to filter instantly
2. **Dashboard auto-refreshes**: Updates every 30 seconds automatically
3. **Click anywhere**: UI is fully interactive
4. **Stock is live**: All changes persist in database
5. **Color = urgency**: Red = critical, Yellow = warning, Green = good

---

**Happy pharmacy managing! 🏥💊**
