import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-8fd38b42/health", (c) => {
  return c.json({ status: "ok" });
});

// ============================================
// MEDICINES ROUTES
// ============================================

// Get all medicines
app.get("/make-server-8fd38b42/medicines", async (c) => {
  try {
    const medicines = await kv.getByPrefix("medicine:");
    return c.json({ success: true, data: medicines });
  } catch (error) {
    console.log(`Error fetching medicines: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Get single medicine
app.get("/make-server-8fd38b42/medicines/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const medicine = await kv.get(`medicine:${id}`);
    if (!medicine) {
      return c.json({ success: false, error: "Medicine not found" }, 404);
    }
    return c.json({ success: true, data: medicine });
  } catch (error) {
    console.log(`Error fetching medicine: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Create medicine
app.post("/make-server-8fd38b42/medicines", async (c) => {
  try {
    const body = await c.req.json();
    const id = body.id || `MED${Date.now()}`;
    const medicine = {
      ...body,
      id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    await kv.set(`medicine:${id}`, medicine);
    return c.json({ success: true, data: medicine });
  } catch (error) {
    console.log(`Error creating medicine: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Update medicine
app.put("/make-server-8fd38b42/medicines/:id", async (c) => {
  try {
    const id = c.req.param("id");
    const body = await c.req.json();
    const existing = await kv.get(`medicine:${id}`);
    if (!existing) {
      return c.json({ success: false, error: "Medicine not found" }, 404);
    }
    const updated = {
      ...existing,
      ...body,
      id,
      updatedAt: new Date().toISOString(),
    };
    await kv.set(`medicine:${id}`, updated);
    return c.json({ success: true, data: updated });
  } catch (error) {
    console.log(`Error updating medicine: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Delete medicine
app.delete("/make-server-8fd38b42/medicines/:id", async (c) => {
  try {
    const id = c.req.param("id");
    await kv.del(`medicine:${id}`);
    return c.json({ success: true });
  } catch (error) {
    console.log(`Error deleting medicine: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// ============================================
// INVENTORY ROUTES
// ============================================

// Get all inventory items
app.get("/make-server-8fd38b42/inventory", async (c) => {
  try {
    const inventory = await kv.getByPrefix("inventory:");
    return c.json({ success: true, data: inventory });
  } catch (error) {
    console.log(`Error fetching inventory: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Create/Update inventory item
app.post("/make-server-8fd38b42/inventory", async (c) => {
  try {
    const body = await c.req.json();
    const id = body.id || `INV${Date.now()}`;
    const item = {
      ...body,
      id,
      updatedAt: new Date().toISOString(),
    };
    await kv.set(`inventory:${id}`, item);
    return c.json({ success: true, data: item });
  } catch (error) {
    console.log(`Error saving inventory: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Update stock quantity
app.patch("/make-server-8fd38b42/inventory/:id/stock", async (c) => {
  try {
    const id = c.req.param("id");
    const { quantity, operation } = await c.req.json(); // operation: 'add' | 'subtract' | 'set'
    const existing = await kv.get(`inventory:${id}`);
    if (!existing) {
      return c.json({ success: false, error: "Inventory item not found" }, 404);
    }
    
    let newQuantity = existing.quantity;
    if (operation === 'add') {
      newQuantity += quantity;
    } else if (operation === 'subtract') {
      newQuantity -= quantity;
    } else if (operation === 'set') {
      newQuantity = quantity;
    }
    
    const updated = {
      ...existing,
      quantity: Math.max(0, newQuantity),
      updatedAt: new Date().toISOString(),
    };
    await kv.set(`inventory:${id}`, updated);
    return c.json({ success: true, data: updated });
  } catch (error) {
    console.log(`Error updating stock: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// ============================================
// PURCHASE ORDERS ROUTES
// ============================================

// Get all purchase orders
app.get("/make-server-8fd38b42/purchase-orders", async (c) => {
  try {
    const orders = await kv.getByPrefix("po:");
    return c.json({ success: true, data: orders });
  } catch (error) {
    console.log(`Error fetching purchase orders: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Create purchase order
app.post("/make-server-8fd38b42/purchase-orders", async (c) => {
  try {
    const body = await c.req.json();
    const id = body.id || `PO${Date.now()}`;
    const order = {
      ...body,
      id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    await kv.set(`po:${id}`, order);
    return c.json({ success: true, data: order });
  } catch (error) {
    console.log(`Error creating purchase order: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Update purchase order status
app.patch("/make-server-8fd38b42/purchase-orders/:id/status", async (c) => {
  try {
    const id = c.req.param("id");
    const { status } = await c.req.json();
    const existing = await kv.get(`po:${id}`);
    if (!existing) {
      return c.json({ success: false, error: "Purchase order not found" }, 404);
    }
    const updated = {
      ...existing,
      status,
      updatedAt: new Date().toISOString(),
    };
    await kv.set(`po:${id}`, updated);
    return c.json({ success: true, data: updated });
  } catch (error) {
    console.log(`Error updating purchase order status: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// ============================================
// PRESCRIPTIONS ROUTES
// ============================================

// Get all prescriptions
app.get("/make-server-8fd38b42/prescriptions", async (c) => {
  try {
    const prescriptions = await kv.getByPrefix("prescription:");
    return c.json({ success: true, data: prescriptions });
  } catch (error) {
    console.log(`Error fetching prescriptions: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Create prescription
app.post("/make-server-8fd38b42/prescriptions", async (c) => {
  try {
    const body = await c.req.json();
    const id = body.id || `RX${Date.now()}`;
    const prescription = {
      ...body,
      id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    await kv.set(`prescription:${id}`, prescription);
    
    // Auto-deduct stock if fulfilled
    if (body.status === 'fulfilled' && body.items) {
      for (const item of body.items) {
        const invItem = await kv.get(`inventory:${item.medicineId}`);
        if (invItem) {
          const updated = {
            ...invItem,
            quantity: Math.max(0, invItem.quantity - item.quantity),
            updatedAt: new Date().toISOString(),
          };
          await kv.set(`inventory:${item.medicineId}`, updated);
        }
      }
    }
    
    return c.json({ success: true, data: prescription });
  } catch (error) {
    console.log(`Error creating prescription: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Update prescription status
app.patch("/make-server-8fd38b42/prescriptions/:id/status", async (c) => {
  try {
    const id = c.req.param("id");
    const { status } = await c.req.json();
    const existing = await kv.get(`prescription:${id}`);
    if (!existing) {
      return c.json({ success: false, error: "Prescription not found" }, 404);
    }
    
    // Auto-deduct stock when status changes to fulfilled
    if (status === 'fulfilled' && existing.status !== 'fulfilled' && existing.items) {
      for (const item of existing.items) {
        const invItem = await kv.get(`inventory:${item.medicineId}`);
        if (invItem) {
          const updated = {
            ...invItem,
            quantity: Math.max(0, invItem.quantity - item.quantity),
            updatedAt: new Date().toISOString(),
          };
          await kv.set(`inventory:${item.medicineId}`, updated);
        }
      }
    }
    
    const updated = {
      ...existing,
      status,
      updatedAt: new Date().toISOString(),
    };
    await kv.set(`prescription:${id}`, updated);
    return c.json({ success: true, data: updated });
  } catch (error) {
    console.log(`Error updating prescription status: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// ============================================
// SALES ROUTES
// ============================================

// Get all sales
app.get("/make-server-8fd38b42/sales", async (c) => {
  try {
    const sales = await kv.getByPrefix("sale:");
    return c.json({ success: true, data: sales });
  } catch (error) {
    console.log(`Error fetching sales: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Create sale
app.post("/make-server-8fd38b42/sales", async (c) => {
  try {
    const body = await c.req.json();
    const id = body.id || `SALE${Date.now()}`;
    const sale = {
      ...body,
      id,
      createdAt: new Date().toISOString(),
    };
    await kv.set(`sale:${id}`, sale);
    
    // Auto-deduct stock
    if (body.items) {
      for (const item of body.items) {
        const invItem = await kv.get(`inventory:${item.medicineId}`);
        if (invItem) {
          const updated = {
            ...invItem,
            quantity: Math.max(0, invItem.quantity - item.quantity),
            updatedAt: new Date().toISOString(),
          };
          await kv.set(`inventory:${item.medicineId}`, updated);
        }
      }
    }
    
    return c.json({ success: true, data: sale });
  } catch (error) {
    console.log(`Error creating sale: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Get dashboard stats
app.get("/make-server-8fd38b42/dashboard/stats", async (c) => {
  try {
    const medicines = await kv.getByPrefix("medicine:");
    const inventory = await kv.getByPrefix("inventory:");
    const sales = await kv.getByPrefix("sale:");
    const prescriptions = await kv.getByPrefix("prescription:");
    
    // Calculate low stock items (treat non-positive reorderLevel as default threshold)
    const LOW_STOCK_THRESHOLD = 100;
    const lowStockItems = inventory.filter((item: any) => {
      const level = item.reorderLevel && item.reorderLevel > 0 ? item.reorderLevel : LOW_STOCK_THRESHOLD;
      return item.quantity < level;
    }).length;
    
    // Calculate expiring medicines (within 30 days)
    const todayDate = new Date();
    const thirtyDaysFromNow = new Date();
    thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30);
    const expiringItems = inventory.filter((item: any) => {
      if (item.expiryDate) {
        const expiryDate = new Date(item.expiryDate);
        return expiryDate <= thirtyDaysFromNow && expiryDate > todayDate;
      }
      return false;
    }).length;
    // Calculate already expired items
    const expiredItemsCount = inventory.filter((item: any) => {
      if (item.expiryDate) {
        const expiryDate = new Date(item.expiryDate);
        return expiryDate <= todayDate;
      }
      return false;
    }).length;
    
    // Calculate today's sales
    const today = new Date().toISOString().split('T')[0];
    const todaySales = sales.filter((sale: any) => 
      sale.createdAt?.startsWith(today)
    );
    const dailySalesTotal = todaySales.reduce((sum: number, sale: any) => sum + (sale.total || 0), 0);
    
    // Pending prescriptions
    const pendingPrescriptions = prescriptions.filter((rx: any) => rx.status === 'pending').length;
    
    return c.json({
      success: true,
      data: {
        totalMedicines: medicines.length,
        lowStockItems,
        expiringMedicines: expiringItems,
        expiredItems: expiredItemsCount,
        dailySales: dailySalesTotal,
        todaySalesCount: todaySales.length,
        pendingPrescriptions,
        totalInventoryValue: inventory.reduce((sum: any, item: any) => 
          sum + (item.quantity * item.unitPrice || 0), 0
        ),
      }
    });
  } catch (error) {
    console.log(`Error fetching dashboard stats: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

// Initialize with sample data
app.post("/make-server-8fd38b42/initialize", async (c) => {
  try {
    // Check if already initialized
    const existing = await kv.get("system:initialized");
    if (existing) {
      return c.json({ success: true, message: "Already initialized" });
    }
    
    // Sample medicines
    const medicines = [
      { id: "MED001", name: "Amoxicillin", genericName: "Amoxicillin", category: "Antibiotics", manufacturer: "PharmaCorp", strength: "500mg", form: "Capsule", price: 0.45, status: "active" },
      { id: "MED002", name: "Ibuprofen", genericName: "Ibuprofen", category: "Pain Relief", manufacturer: "MediLabs", strength: "400mg", form: "Tablet", price: 0.25, status: "active" },
      { id: "MED003", name: "Paracetamol", genericName: "Acetaminophen", category: "Pain Relief", manufacturer: "HealthCare Inc", strength: "500mg", form: "Tablet", price: 0.15, status: "active" },
      { id: "MED004", name: "Metformin", genericName: "Metformin HCl", category: "Diabetes", manufacturer: "DiaCare", strength: "850mg", form: "Tablet", price: 0.35, status: "active" },
      { id: "MED005", name: "Lisinopril", genericName: "Lisinopril", category: "Cardiovascular", manufacturer: "CardioPharma", strength: "10mg", form: "Tablet", price: 0.55, status: "active" },
    ];
    
    for (const med of medicines) {
      await kv.set(`medicine:${med.id}`, { ...med, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
    }
    
    // Sample inventory
    const inventory = [
      { id: "INV001", medicineId: "MED001", medicineName: "Amoxicillin", batchNumber: "BATCH001", quantity: 500, reorderLevel: 100, expiryDate: "2026-12-31", unitPrice: 0.45, location: "Shelf A1" },
      { id: "INV002", medicineId: "MED002", medicineName: "Ibuprofen", batchNumber: "BATCH002", quantity: 800, reorderLevel: 200, expiryDate: "2026-08-15", unitPrice: 0.25, location: "Shelf B2" },
      { id: "INV003", medicineId: "MED003", medicineName: "Paracetamol", batchNumber: "BATCH003", quantity: 50, reorderLevel: 150, expiryDate: "2026-03-10", unitPrice: 0.15, location: "Shelf C1" },
      { id: "INV004", medicineId: "MED004", medicineName: "Metformin", batchNumber: "BATCH004", quantity: 300, reorderLevel: 100, expiryDate: "2027-01-20", unitPrice: 0.35, location: "Shelf D3" },
      { id: "INV005", medicineId: "MED005", medicineName: "Lisinopril", batchNumber: "BATCH005", quantity: 45, reorderLevel: 80, expiryDate: "2026-06-30", unitPrice: 0.55, location: "Shelf E2" },
    ];
    
    for (const inv of inventory) {
      await kv.set(`inventory:${inv.id}`, { ...inv, updatedAt: new Date().toISOString() });
    }
    
    await kv.set("system:initialized", { initialized: true, date: new Date().toISOString() });
    
    return c.json({ success: true, message: "System initialized with sample data" });
  } catch (error) {
    console.log(`Error initializing system: ${error}`);
    return c.json({ success: false, error: String(error) }, 500);
  }
});

Deno.serve(app.fetch);