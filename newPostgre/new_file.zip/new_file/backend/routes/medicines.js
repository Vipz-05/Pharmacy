const express = require('express');
const router = express.Router();
const pool = require('../db');

// List all medicines
router.get('/', async (req, res) => {
  try {
    const { search } = req.query;
    let query = 'SELECT * FROM MEDICINE ORDER BY name ASC';
    const params = [];

    if (search) {
      query = `SELECT * FROM MEDICINE 
               WHERE name ILIKE $1 OR medicine_code ILIKE $1 OR manufacturer ILIKE $1
               ORDER BY name ASC`;
      params.push(`%${search}%`);
    }

    const result = await pool.query(query, params);
    
    // Map database columns to camelCase for frontend
    const mappedData = result.rows.map(row => ({
      id: row.medicine_id,
      medicineCode: row.medicine_code,
      name: row.name,
      category: row.category,
      manufacturer: row.manufacturer,
      dosageForm: row.dosage_form,
      strength: row.strength,
      prescriptionRequired: row.prescription_required,
      createdAt: row.created_at,
      // Add fields expected by frontend
      genericName: row.name,
      form: row.dosage_form,
      price: 0,
      status: 'active'
    }));
    
    res.json({ success: true, data: mappedData });
  } catch (err) {
    console.error('Error fetching medicines:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Get single medicine
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('SELECT * FROM MEDICINE WHERE medicine_id = $1', [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Medicine not found' });
    }

    const row = result.rows[0];
    const mappedData = {
      id: row.medicine_id,
      medicineCode: row.medicine_code,
      name: row.name,
      category: row.category,
      manufacturer: row.manufacturer,
      dosageForm: row.dosage_form,
      strength: row.strength,
      prescriptionRequired: row.prescription_required,
      createdAt: row.created_at,
      genericName: row.name,
      form: row.dosage_form,
      price: 0,
      status: 'active'
    };

    res.json({ success: true, data: mappedData });
  } catch (err) {
    console.error('Error fetching medicine:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Create medicine
router.post('/', async (req, res) => {
  try {
    const { name, category, manufacturer, dosageForm, strength, prescriptionRequired, medicineCode } = req.body;

    if (!name || !medicineCode) {
      return res.status(400).json({ success: false, error: 'Name and medicine code are required' });
    }

    const result = await pool.query(
      `INSERT INTO MEDICINE (medicine_code, name, category, manufacturer, dosage_form, strength, prescription_required)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING *`,
      [medicineCode, name, category, manufacturer, dosageForm, strength, prescriptionRequired !== false]
    );

    res.status(201).json({ success: true, data: result.rows[0] });
  } catch (err) {
    console.error('Error creating medicine:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Update medicine
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { name, category, manufacturer, dosageForm, strength, prescriptionRequired } = req.body;

    const result = await pool.query(
      `UPDATE MEDICINE 
       SET name = COALESCE($1, name),
           category = COALESCE($2, category),
           manufacturer = COALESCE($3, manufacturer),
           dosage_form = COALESCE($4, dosage_form),
           strength = COALESCE($5, strength),
           prescription_required = COALESCE($6, prescription_required)
       WHERE medicine_id = $7
       RETURNING *`,
      [name, category, manufacturer, dosageForm, strength, prescriptionRequired, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Medicine not found' });
    }

    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    console.error('Error updating medicine:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Delete medicine
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('DELETE FROM MEDICINE WHERE medicine_id = $1 RETURNING *', [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Medicine not found' });
    }

    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    console.error('Error deleting medicine:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
