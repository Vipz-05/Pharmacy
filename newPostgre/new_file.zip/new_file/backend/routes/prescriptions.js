const express = require('express');
const router = express.Router();
const pool = require('../db');

// Get all prescriptions
router.get('/', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        p.prescription_id as id,
        'RX' || p.prescription_id::text as prescriptionId,
        p.patient_id as patientId,
        p.patient_name as patientName,
        p.doctor_id as doctorId,
        p.doctor_name as doctorName,
        p.prescription_date as date,
        p.status,
        COUNT(pi.item_id) as itemCount
      FROM PRESCRIPTION p
      LEFT JOIN PRESCRIPTION_ITEM pi ON p.prescription_id = pi.prescription_id
      GROUP BY p.prescription_id
      ORDER BY p.prescription_date DESC
    `);
    
    res.json({ success: true, data: result.rows });
  } catch (err) {
    console.error('Error fetching prescriptions:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Get prescription details
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const presResult = await pool.query(
      'SELECT * FROM PRESCRIPTION WHERE prescription_id = $1',
      [id]
    );

    if (presResult.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Prescription not found' });
    }

    const items = await pool.query(
      `SELECT pi.*, m.name as medicineName
       FROM PRESCRIPTION_ITEM pi
       JOIN MEDICINE m ON pi.medicine_id = m.medicine_id
       WHERE pi.prescription_id = $1`,
      [id]
    );

    res.json({ 
      success: true, 
      data: {
        ...presResult.rows[0],
        items: items.rows
      }
    });
  } catch (err) {
    console.error('Error fetching prescription:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Create prescription
router.post('/', async (req, res) => {
  const client = await pool.connect();

  try {
    const { patientId, patientName, doctorId, doctorName, items } = req.body;

    if (!patientId || !doctorId || !items || items.length === 0) {
      return res.status(400).json({ success: false, error: 'Patient, doctor, and items required' });
    }

    await client.query('BEGIN');

    const presResult = await client.query(
      `INSERT INTO PRESCRIPTION (patient_id, patient_name, doctor_id, doctor_name, prescription_date, status)
       VALUES ($1, $2, $3, $4, CURRENT_DATE, 'pending')
       RETURNING *`,
      [patientId, patientName, doctorId, doctorName]
    );

    const presId = presResult.rows[0].prescription_id;

    for (const item of items) {
      await client.query(
        `INSERT INTO PRESCRIPTION_ITEM (prescription_id, medicine_id, dosage, duration_days)
         VALUES ($1, $2, $3, $4)`,
        [presId, item.medicineId, item.dosage, item.durationDays]
      );
    }

    await client.query('COMMIT');

    res.status(201).json({ success: true, data: { prescription_id: presId } });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Error creating prescription:', err);
    res.status(500).json({ success: false, error: err.message });
  } finally {
    client.release();
  }
});

// Update prescription status
router.patch('/:id/status', async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const result = await pool.query(
      'UPDATE PRESCRIPTION SET status = $1 WHERE prescription_id = $2 RETURNING *',
      [status, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Prescription not found' });
    }

    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    console.error('Error updating prescription:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
