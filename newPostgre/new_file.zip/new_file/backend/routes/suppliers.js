const express = require('express');
const router = express.Router();
const pool = require('../db');

// List all suppliers
router.get('/', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM SUPPLIER ORDER BY supplier_name ASC');
    res.json({ success: true, data: result.rows });
  } catch (err) {
    console.error('Error fetching suppliers:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Get single supplier
router.get('/:id', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM SUPPLIER WHERE supplier_id = $1', [req.params.id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Supplier not found' });
    }

    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    console.error('Error fetching supplier:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Create supplier
router.post('/', async (req, res) => {
  try {
    const { supplierName, contactPerson, phone, email } = req.body;

    if (!supplierName) {
      return res.status(400).json({ success: false, error: 'Supplier name is required' });
    }

    const result = await pool.query(
      `INSERT INTO SUPPLIER (supplier_name, contact_person, phone, email)
       VALUES ($1, $2, $3, $4)
       RETURNING supplier_id as id, supplier_name as name, contact_person as contactPerson, phone, email`,
      [supplierName, contactPerson, phone, email]
    );

    res.status(201).json({ success: true, data: result.rows[0] });
  } catch (err) {
    console.error('Error creating supplier:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Update supplier
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { supplierName, contactPerson, phone, email } = req.body;

    const result = await pool.query(
      `UPDATE SUPPLIER 
       SET supplier_name = COALESCE($1, supplier_name),
           contact_person = COALESCE($2, contact_person),
           phone = COALESCE($3, phone),
           email = COALESCE($4, email)
       WHERE supplier_id = $5
       RETURNING supplier_id as id, supplier_name as name`,
      [supplierName, contactPerson, phone, email, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Supplier not found' });
    }

    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    console.error('Error updating supplier:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
