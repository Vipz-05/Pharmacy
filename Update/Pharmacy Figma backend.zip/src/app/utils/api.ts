import { projectId, publicAnonKey } from '/utils/supabase/info';

const API_BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-8fd38b42`;

const headers = {
  'Content-Type': 'application/json',
  'Authorization': `Bearer ${publicAnonKey}`,
};

// Generic API call handler
async function apiCall<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      ...options,
      headers: {
        ...headers,
        ...options.headers,
      },
    });

    const data = await response.json();

    if (!response.ok) {
      console.error(`API error on ${endpoint}:`, data);
      throw new Error(data.error || 'API request failed');
    }

    return data;
  } catch (error) {
    console.error(`API call failed for ${endpoint}:`, error);
    throw error;
  }
}

// ============================================
// MEDICINES API
// ============================================

export const medicinesApi = {
  getAll: () => apiCall<{ success: boolean; data: any[] }>('/medicines'),
  
  getById: (id: string) => apiCall<{ success: boolean; data: any }>(`/medicines/${id}`),
  
  create: (medicine: any) =>
    apiCall<{ success: boolean; data: any }>('/medicines', {
      method: 'POST',
      body: JSON.stringify(medicine),
    }),
  
  update: (id: string, medicine: any) =>
    apiCall<{ success: boolean; data: any }>(`/medicines/${id}`, {
      method: 'PUT',
      body: JSON.stringify(medicine),
    }),
  
  delete: (id: string) =>
    apiCall<{ success: boolean }>(`/medicines/${id}`, {
      method: 'DELETE',
    }),
};

// ============================================
// INVENTORY API
// ============================================

export const inventoryApi = {
  getAll: () => apiCall<{ success: boolean; data: any[] }>('/inventory'),
  
  create: (item: any) =>
    apiCall<{ success: boolean; data: any }>('/inventory', {
      method: 'POST',
      body: JSON.stringify(item),
    }),
  
  updateStock: (id: string, quantity: number, operation: 'add' | 'subtract' | 'set') =>
    apiCall<{ success: boolean; data: any }>(`/inventory/${id}/stock`, {
      method: 'PATCH',
      body: JSON.stringify({ quantity, operation }),
    }),
};

// ============================================
// PURCHASE ORDERS API
// ============================================

export const purchaseOrdersApi = {
  getAll: () => apiCall<{ success: boolean; data: any[] }>('/purchase-orders'),
  
  create: (order: any) =>
    apiCall<{ success: boolean; data: any }>('/purchase-orders', {
      method: 'POST',
      body: JSON.stringify(order),
    }),
  
  updateStatus: (id: string, status: string) =>
    apiCall<{ success: boolean; data: any }>(`/purchase-orders/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    }),
};

// ============================================
// PRESCRIPTIONS API
// ============================================

export const prescriptionsApi = {
  getAll: () => apiCall<{ success: boolean; data: any[] }>('/prescriptions'),
  
  create: (prescription: any) =>
    apiCall<{ success: boolean; data: any }>('/prescriptions', {
      method: 'POST',
      body: JSON.stringify(prescription),
    }),
  
  updateStatus: (id: string, status: string) =>
    apiCall<{ success: boolean; data: any }>(`/prescriptions/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    }),
};

// ============================================
// SALES API
// ============================================

export const salesApi = {
  getAll: () => apiCall<{ success: boolean; data: any[] }>('/sales'),
  
  create: (sale: any) =>
    apiCall<{ success: boolean; data: any }>('/sales', {
      method: 'POST',
      body: JSON.stringify(sale),
    }),
};

// ============================================
// DASHBOARD API
// ============================================

export const dashboardApi = {
  getStats: () => apiCall<{ success: boolean; data: any }>('/dashboard/stats'),
};

// ============================================
// SYSTEM API
// ============================================

export const systemApi = {
  initialize: () =>
    apiCall<{ success: boolean; message: string }>('/initialize', {
      method: 'POST',
    }),
};
