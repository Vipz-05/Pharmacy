# Migration Guide: Supabase → PostgreSQL Backend

Complete guide to migrate from Supabase to the new standalone PostgreSQL backend.

## What Changed

### Before (Supabase)

- Backend: Supabase Cloud Functions
- Database: Managed PostgreSQL on Supabase
- API: Edge functions via Supabase URL
- Authentication: Through Supabase client

### After (New Setup)

- Backend: Express.js (Node.js)
- Database: Self-hosted PostgreSQL
- API: REST endpoints on `http://localhost:3001`
- Authentication: To be implemented

## Migration Steps

### 1. Database Migration (if coming from Supabase)

#### Option A: Data Export/Import

```bash
# Export from Supabase
pg_dump -h db.xxxxx.supabase.co -U postgres pharmacy_db > backup.sql

# Import to local PostgreSQL
psql -U postgres -d pharmacy_db -f backup.sql
```

#### Option B: Manual Schema Recreation

Simply run the schema provided in `backend/schema.sql` with empty tables.

### 2. Frontend Changes

Already done! The API client (`src/app/utils/api.ts`) has been updated:

**Before:**

```typescript
import { projectId, publicAnonKey } from "/utils/supabase/info";
const API_BASE_URL = `https://${projectId}.supabase.co/functions/v1/...`;
const headers = { Authorization: `Bearer ${publicAnonKey}` };
```

**After:**

```typescript
const API_BASE_URL = "http://localhost:3001/api";
const headers = { "Content-Type": "application/json" };
```

### 3. Start the Backend

```bash
cd backend
npm install
npm run dev
```

The backend will start on `http://localhost:3001`

### 4. Start the Frontend

```bash
npm run dev
```

The frontend will start on `http://localhost:5173` and communicate with the backend.

## API Compatibility

All API endpoints remain the same structure:

```typescript
{
  success: true,
  data: { /* ... */ }
}
```

### Endpoint Changes

| Operation         | Before                  | After                       |
| ----------------- | ----------------------- | --------------------------- |
| List medicines    | `/medicines`            | `/api/medicines`            |
| Get inventory     | `/inventory`            | `/api/inventory`            |
| Create PO         | `POST /purchase-orders` | `POST /api/purchase-orders` |
| Get prescriptions | `/prescriptions`        | `/api/prescriptions`        |
| Process sale      | `POST /sales`           | `POST /api/sales`           |

No code changes needed in components since the API client handles routing.

## Component Compatibility

All existing React components work without modification:

- ✅ Dashboard
- ✅ Inventory Management
- ✅ Medicine Master
- ✅ Prescriptions
- ✅ Purchase Orders
- ✅ Sales & Billing

The components import from `utils/api` which now routes to the new backend.

## Environment Configuration

### Frontend (.env)

```env
VITE_API_URL=http://localhost:3001/api
```

This is already set in the root `.env` file.

### Backend (.env)

```env
DB_HOST=localhost
DB_PORT=5432
DB_NAME=pharmacy_db
DB_USER=postgres
DB_PASSWORD=postgres
PORT=3001
NODE_ENV=development
FRONTEND_URL=http://localhost:5173
```

## File Structure Changes

### Added Files

```
backend/                    # New backend directory
├── server.js              # Express application
├── db.js                  # Database connection
├── package.json           # Node.js dependencies
├── schema.sql             # PostgreSQL schema
├── .env.example           # Environment template
└── routes/                # API route handlers
    ├── medicines.js
    ├── inventory.js
    ├── suppliers.js
    ├── purchaseOrders.js
    ├── prescriptions.js
    ├── sales.js
    └── dashboard.js
```

### Modified Files

```
src/app/utils/api.ts       # Now uses local backend (v2)
.env                       # Added VITE_API_URL
```

### Removed/Obsolete

```
utils/supabase/info.tsx    # No longer used
supabase/functions/        # Replaced by backend/
```

## Database Schema Compatibility

The new PostgreSQL schema (`backend/schema.sql`) includes:

- All required tables with proper relationships
- Indexes for performance
- Constraints for data integrity
- CASCADE deletes where appropriate

Existing data from Supabase can be directly migrated (structure is compatible).

## Testing the Migration

### Health Check

```bash
curl http://localhost:3001/api/health
# Response: { "status": "ok", "database": "connected" }
```

### Test API Endpoint

```bash
curl http://localhost:3001/api/medicines
# Response: { "success": true, "data": [...] }
```

### Frontend Verification

1. Open http://localhost:5173
2. Navigate to each module (Dashboard, Inventory, etc.)
3. Verify data loads and operations work

## Rollback Plan

If you need to revert to Supabase temporarily:

1. Restore original `.env` with Supabase keys
2. Revert `src/app/utils/api.ts` to use Supabase URLs
3. Restart frontend: `npm run dev`

## Troubleshooting

### Database Connection Error

```
Error: connect ECONNREFUSED 127.0.0.1:5432
```

**Solution:**

- Ensure PostgreSQL is running
- Check `.env` database credentials
- Verify database exists: `psql -l`

### CORS Error in Console

```
Access-Control-Allow-Origin error
```

**Solution:**

- Verify `FRONTEND_URL` in `backend/.env` matches your frontend URL

### API 404 Errors

```
Cannot POST /api/medicines
```

**Solution:**

- Ensure backend is running on port 3001
- Verify correct API endpoint in frontend code

### Module Not Found Errors

```
Cannot find module 'pg'
```

**Solution:**

```bash
cd backend
npm install pg
```

## Performance Considerations

### Previously with Supabase

- Cold starts on functions (100-500ms)
- Network latency to cloud

### Now with Local Backend

- Faster response times (1-10ms)
- Direct database connection
- No function initialization overhead

## Next Steps

### Recommended

1. ✅ Complete migration (you are here)
2. 🔄 Set up automated backups for PostgreSQL
3. 🔐 Add authentication/authorization
4. 📊 Add API logging
5. 🚀 Deploy to production server

### Optional

- Add database migrations tool (Flyway, Liquibase)
- Set up CI/CD pipeline
- Add API documentation (Swagger)
- Implement caching (Redis)

## Support

If you encounter issues:

1. Check backend logs: `npm run dev` terminal
2. Verify database connectivity: `psql -d pharmacy_db -c "SELECT 1"`
3. Test API directly: `curl http://localhost:3001/api/health`
4. Check frontend console for error messages

---

**Migration Status:** ✅ Complete
**Date:** February 2026
**Backend Ready:** Yes
**Database Ready:** Yes
**Frontend Ready:** Yes
