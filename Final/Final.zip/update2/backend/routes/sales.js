const express = require('express');
const router = express.Router();
const pool = require('../db');
const { sendServerError } = require('../utils/errorResponse');

// Get all sales
router.get('/', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT 
        s.sale_id as id,
        'INV-' || s.sale_id::text as "invoiceId",
        s.sale_date as "date",
        s.total_amount as total,
        s.payment_method as "paymentMethod",
        COUNT(si.item_id) as items
      FROM PHARMACY_SALE s
      LEFT JOIN PHARMACY_SALE_ITEM si ON s.sale_id = si.sale_id
      GROUP BY s.sale_id
      ORDER BY s.sale_date DESC
      LIMIT 50
    `);
    
    res.json({ success: true, data: result.rows });
  } catch (err) {
    return sendServerError(res, err, 'Error fetching sales:');
  }
});

// Get sale details
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const sale = await pool.query(
      'SELECT * FROM PHARMACY_SALE WHERE sale_id = $1',
      [id]
    );

    if (sale.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Sale not found' });
    }

    const items = await pool.query(
      `SELECT si.*, m.name as medicineName, mb.batch_number
       FROM PHARMACY_SALE_ITEM si
       JOIN MEDICINE m ON si.medicine_id = m.medicine_id
       LEFT JOIN MEDICINE_BATCH mb ON si.batch_id = mb.batch_id
       WHERE si.sale_id = $1`,
      [id]
    );

    res.json({ 
      success: true, 
      data: {
        ...sale.rows[0],
        items: items.rows
      }
    });
  } catch (err) {
    return sendServerError(res, err, 'Error fetching sale:');
  }
});

// Process sale (create sale and reduce inventory)
router.post('/', async (req, res) => {
  const client = await pool.connect();

  try {
    const { prescriptionId, items, paymentMethod, totalAmount } = req.body;

    if (!items || items.length === 0) {
      return res.status(400).json({ success: false, error: 'Items required' });
    }

    for (const item of items) {
      if (!item.medicineId || !item.batchId || !Number.isFinite(item.quantity) || item.quantity <= 0) {
        return res.status(400).json({ success: false, error: 'Each item must include medicineId, batchId, and positive quantity' });
      }
    }

    await client.query('BEGIN');

    // Create sale
    const saleResult = await client.query(
      `INSERT INTO PHARMACY_SALE (prescription_id, sale_date, payment_method, total_amount)
       VALUES ($1, CURRENT_TIMESTAMP, $2, $3)
       RETURNING *`,
      [prescriptionId, paymentMethod, totalAmount]
    );

    const saleId = saleResult.rows[0].sale_id;

    // Add items and reduce inventory
    for (const item of items) {
      // Add to sale items
      await client.query(
        `INSERT INTO PHARMACY_SALE_ITEM (sale_id, medicine_id, batch_id, quantity, price)
         VALUES ($1, $2, $3, $4, $5)`,
        [saleId, item.medicineId, item.batchId, item.quantity, item.price]
      );

      // Reduce batch quantity, but only when enough stock is available.
      const stockUpdate = await client.query(
        `UPDATE MEDICINE_BATCH
         SET quantity_available = quantity_available - $1
         WHERE batch_id = $2
           AND medicine_id = $3
           AND quantity_available >= $1
         RETURNING batch_id`,
        [item.quantity, item.batchId, item.medicineId]
      );

      if (stockUpdate.rows.length === 0) {
        const stockError = new Error(`Insufficient stock or invalid batch for medicine ${item.medicineId}`);
        stockError.statusCode = 400;
        throw stockError;
      }
    }

    // Update prescription status if provided
    if (prescriptionId) {
      await client.query(
        'UPDATE PRESCRIPTION SET status = $1 WHERE prescription_id = $2',
        ['fulfilled', prescriptionId]
      );
    }

    await client.query('COMMIT');

    res.status(201).json({ success: true, data: { sale_id: saleId } });
  } catch (err) {
    await client.query('ROLLBACK');
    if (err.statusCode) {
      return res.status(err.statusCode).json({ success: false, error: err.message });
    }
    return sendServerError(res, err, 'Error processing sale:');
  } finally {
    client.release();
  }
});

module.exports = router;
