const express = require('express');
const router = express.Router();
const pool = require('../db');
const { sendServerError } = require('../utils/errorResponse');

async function hasPurchaseQuantityColumn() {
  const result = await pool.query(
    `SELECT EXISTS (
       SELECT 1
       FROM information_schema.columns
       WHERE table_schema = 'public'
         AND table_name = 'medicine_batch'
         AND column_name = 'purchase_quantity'
     ) as exists`
  );
  return Boolean(result.rows[0]?.exists);
}

// Get all inventory batches with medicine details
router.get('/', async (req, res) => {
  try {
    const hasPurchaseQty = await hasPurchaseQuantityColumn();
    const purchaseQtySelect = hasPurchaseQty
      ? 'COALESCE(mb.purchase_quantity, mb.quantity_available)'
      : 'mb.quantity_available';

    const result = await pool.query(
      `
      SELECT 
        mb.batch_id as "id",
        mb.medicine_id as "medicineId",
        m.name as "medicineName",
        m.manufacturer as "manufacturer",
        mb.batch_number as "batchNumber",
        ${purchaseQtySelect} as "purchaseQuantity",
        mb.quantity_available as "quantity",
        COALESCE(mb.reorder_level, 100) as "reorderLevel",
        mb.expiry_date as "expiryDate",
        m.unit_price as "unitPrice",
        COALESCE(mb.location, 'Shelf A') as "location",
        (
          SELECT COUNT(*)
          FROM PHARMACY_SALE_ITEM psi
          WHERE psi.batch_id = mb.batch_id
        ) as "salesReferences"
      FROM MEDICINE_BATCH mb
      JOIN MEDICINE m ON mb.medicine_id = m.medicine_id
      ORDER BY m.name ASC
    `
    );
    
    res.json({ success: true, data: result.rows });
  } catch (err) {
    return sendServerError(res, err, 'Error fetching inventory:');
  }
});

// Add medicine batch (addMedicineBatch API)
router.post('/', async (req, res) => {
  try {
    const { medicineId, expiryDate, quantity, location, reorderLevel } = req.body;

    if (!medicineId || !Number.isFinite(Number(quantity)) || Number(quantity) <= 0) {
      return res.status(400).json({ success: false, error: 'Medicine ID and valid quantity are required' });
    }

    // Check if medicine exists
    const medicineCheck = await pool.query('SELECT unit_price FROM MEDICINE WHERE medicine_id = $1', [medicineId]);
    if (medicineCheck.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Medicine not found' });
    }

    const unitPrice = Number(medicineCheck.rows[0].unit_price || 0);

    const normalizedLocation =
      typeof location === 'string' && location.trim().length > 0 ? location.trim() : 'Shelf A';
    const parsedReorderLevel = Number(reorderLevel);
    const normalizedReorderLevel =
      Number.isFinite(parsedReorderLevel) && parsedReorderLevel >= 0 ? parsedReorderLevel : 100;

    const hasPurchaseQty = await hasPurchaseQuantityColumn();
    const insertQuery = hasPurchaseQty
      ? `WITH next_batch AS (
           SELECT nextval(pg_get_serial_sequence('medicine_batch', 'batch_id')) AS batch_id
         )
         INSERT INTO MEDICINE_BATCH
          (batch_id, medicine_id, batch_number, expiry_date, purchase_price, selling_price, location, reorder_level, purchase_quantity, quantity_available)
         SELECT
          next_batch.batch_id,
          $1,
          'BT-' || next_batch.batch_id::text,
          $2,
          $3,
          $3,
          $4,
          $5,
          $6,
          $6
         FROM next_batch
         RETURNING *`
      : `WITH next_batch AS (
           SELECT nextval(pg_get_serial_sequence('medicine_batch', 'batch_id')) AS batch_id
         )
         INSERT INTO MEDICINE_BATCH
          (batch_id, medicine_id, batch_number, expiry_date, purchase_price, selling_price, location, reorder_level, quantity_available)
         SELECT
          next_batch.batch_id,
          $1,
          'BT-' || next_batch.batch_id::text,
          $2,
          $3,
          $3,
          $4,
          $5,
          $6
         FROM next_batch
         RETURNING *`;

    const result = await pool.query(insertQuery, [
      medicineId,
      expiryDate || null,
      unitPrice,
      normalizedLocation,
      normalizedReorderLevel,
      Number(quantity),
    ]);

    res.status(201).json({ success: true, data: result.rows[0] });
  } catch (err) {
    return sendServerError(res, err, 'Error adding batch:');
  }
});

// Update batch stock
router.patch('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { quantity, operation } = req.body;

    // Get current quantity
    const current = await pool.query('SELECT quantity_available FROM MEDICINE_BATCH WHERE batch_id = $1', [id]);
    if (current.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Batch not found' });
    }

    let newQuantity = current.rows[0].quantity_available;
    if (operation === 'add') {
      newQuantity += quantity;
    } else if (operation === 'subtract') {
      newQuantity = Math.max(0, newQuantity - quantity);
    } else if (operation === 'set') {
      newQuantity = quantity;
    }

    const result = await pool.query(
      'UPDATE MEDICINE_BATCH SET quantity_available = $1 WHERE batch_id = $2 RETURNING *',
      [newQuantity, id]
    );

    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    return sendServerError(res, err, 'Error updating batch:');
  }
});

// Update batch details
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { expiryDate, quantity, location, reorderLevel } = req.body;

    const existing = await pool.query('SELECT * FROM MEDICINE_BATCH WHERE batch_id = $1', [id]);
    if (existing.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Batch not found' });
    }

    const hasPurchaseQty = await hasPurchaseQuantityColumn();
    const parsedQuantity = Number(quantity);
    const parsedReorderLevel = Number(reorderLevel);
    const maxPurchaseQuantity = hasPurchaseQty
      ? Number(existing.rows[0].purchase_quantity ?? existing.rows[0].quantity_available ?? 0)
      : Number(existing.rows[0].quantity_available ?? 0);

    const normalizedQuantity = Number.isFinite(parsedQuantity) && parsedQuantity >= 0
      ? parsedQuantity
      : existing.rows[0].quantity_available;
    const normalizedReorderLevel = Number.isFinite(parsedReorderLevel) && parsedReorderLevel >= 0
      ? parsedReorderLevel
      : (existing.rows[0].reorder_level ?? 100);
    const normalizedLocation =
      typeof location === 'string' && location.trim().length > 0
        ? location.trim()
        : (existing.rows[0].location || 'Shelf A');
    const normalizedExpiryDate = expiryDate || null;

    if (normalizedQuantity > maxPurchaseQuantity) {
      return res.status(400).json({
        success: false,
        error: `Quantity cannot exceed purchased quantity (${maxPurchaseQuantity}).`,
      });
    }

    const result = await pool.query(
      `UPDATE MEDICINE_BATCH
       SET expiry_date = $1,
           quantity_available = $2,
           location = $3,
           reorder_level = $4
       WHERE batch_id = $5
       RETURNING *`,
      [normalizedExpiryDate, normalizedQuantity, normalizedLocation, normalizedReorderLevel, id]
    );

    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    return sendServerError(res, err, 'Error updating batch details:');
  }
});

// Delete batch
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const usageCheck = await pool.query(
      'SELECT COUNT(*)::int as ref_count FROM PHARMACY_SALE_ITEM WHERE batch_id = $1',
      [id]
    );
    const refCount = Number(usageCheck.rows[0]?.ref_count || 0);
    if (refCount > 0) {
      return res.status(409).json({
        success: false,
        error: 'Cannot delete this batch because it is already used in sales records.',
      });
    }

    const result = await pool.query('DELETE FROM MEDICINE_BATCH WHERE batch_id = $1 RETURNING *', [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Batch not found' });
    }

    res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    if (err?.code === '23503') {
      return res.status(409).json({
        success: false,
        error: 'Cannot delete this batch because it is already used in sales records.',
      });
    }
    return sendServerError(res, err, 'Error deleting batch:');
  }
});

module.exports = router;
